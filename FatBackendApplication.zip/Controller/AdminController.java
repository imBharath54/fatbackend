package com.project.fatbackend.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.project.fatbackend.Dto.ServiceDto;
import com.project.fatbackend.Entity.Service;
import com.project.fatbackend.Service.ServicesService;

@RestController
@RequestMapping("api/v1/admin")
@CrossOrigin
public class AdminController {
	@Autowired
	private ServicesService servicesService;
	@GetMapping("/services")
	public ResponseEntity<?> getServices(){
		List<Service> services = servicesService.getServices();
		return ResponseEntity.ok(services);
		
	}
	
	@PostMapping("/services")
	public ResponseEntity<?> saveService(@RequestBody ServiceDto serviceDto){
		Service service = servicesService.addService(serviceDto.getName(), serviceDto.getDescription(), serviceDto.getPrice());
		return ResponseEntity.ok(service);
	}

}
