package com.project.fatbackend.Controller;

import java.util.Enumeration;
import java.util.Iterator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.project.fatbackend.Dto.UserDto;
import com.project.fatbackend.Entity.User;
import com.project.fatbackend.Service.UserService;

import jakarta.servlet.http.HttpSession;


@RestController 
@CrossOrigin("http://localhost:3000")
public class UserController {
	
	@Autowired
	UserService userService;
	
	@GetMapping("/api/user/{email}")
	public ResponseEntity<?> getUser(@PathVariable("email") String email,HttpSession session){
		System.out.println(email);
		Enumeration<String> s= session.getAttributeNames();
        Iterator<String> iterator = s.asIterator();
		System.out.println("-----------");

		while (iterator.hasNext()) {
            String element = iterator.next();
            System.out.println(element);
        }
		System.out.println("-----------");
		try {
    		boolean valid = (boolean)session.getAttribute("valid");
	    	String role = (String) session.getAttribute("role");
	    	String u = (String) session.getAttribute("userid");

	    	System.out.println(role);
	    	System.out.println(valid);
	    	if(valid==true && role.equals("user")) {
	            User user = userService.getUserByEmail(u);
	
	            System.out.println(user);
	
	            if (user != null){
	                UserDto userDto = new  UserDto(user);
	
	                return new ResponseEntity<>(userDto, HttpStatus.OK);
	            }
	            else {return new ResponseEntity<>(new UserDto(),HttpStatus.NOT_FOUND);}
	
	    		
	    	}
    	}
	    	
	    catch (NullPointerException e) {
	    	return new ResponseEntity<>("NO session found",HttpStatus.BAD_REQUEST);   
	    	
	    }
    	return new ResponseEntity<>("Login first",HttpStatus.BAD_REQUEST);   

    			
	}
	
	@PostMapping("/user")
	public ResponseEntity<?> saveUser(@RequestBody User user){
		userService.addUser(user);
		
		return new ResponseEntity<>("user saved successfully",HttpStatus.OK);
		
		
	}
	
	

}
