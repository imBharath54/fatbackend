package com.project.fatbackend.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.project.fatbackend.Dto.ReviewDto;
import com.project.fatbackend.Entity.UserReview;
import com.project.fatbackend.Service.UserReviewImpl;

@RestController
public class UserReviewController {
	
	@Autowired
	UserReviewImpl userReviewService;
	
	@PostMapping("/user/review")
	public ResponseEntity<?> createReview(@RequestBody ReviewDto review){
		
		boolean saved = userReviewService.addReview(review);
		if (saved) {
			return new ResponseEntity<>("saved successfully",HttpStatus.OK);
		}
		
		
		return new ResponseEntity<>("not success",HttpStatus.BAD_GATEWAY);
		
		
	}
	

}
