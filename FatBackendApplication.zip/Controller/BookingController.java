package com.project.fatbackend.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.project.fatbackend.Entity.Booking;
import com.project.fatbackend.Service.BookingService;

@RestController
@CrossOrigin
public class BookingController {
	
	@Autowired
	BookingService bookingService;
	
	@PostMapping("/booking")
	public ResponseEntity<?> createBooking(@RequestBody Booking booking){
		
		Booking booking1 = bookingService.createBooking(booking);
		return ResponseEntity.ok(booking1);
		
	}
	
	@GetMapping("/booking/{id}")
	public ResponseEntity<?> getBooking(@PathVariable Long id ){

		return ResponseEntity.ok(bookingService.getBookingsById(id));
		
	}
		
	
	
	@PostMapping("/booking/assign")
	public ResponseEntity<?> assignTech(@RequestBody Booking booking){
		
		bookingService.save(booking);
		return new ResponseEntity<>("updated",HttpStatus.OK);
	}
	
	@GetMapping("/bookings/{id}")
	public ResponseEntity<?> getBookingsById(@PathVariable("id") Long id){
		return ResponseEntity.ok(bookingService.getBookingsById(id));
	}

}
