package com.project.fatbackend.Entity;

import com.project.fatbackend.Dto.ReviewDto;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class UserReview {
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long reviewId;
	private Long userId;
	private Long techId;
	private Integer rating;
	private String description;
	public UserReview() {
		super();
	}
	
	public UserReview(ReviewDto review) {
		super();
		this.userId = review.getReviewer();
		this.techId = review.getReciever();
		this.rating = review.getRating();
		this.description = review.getDescription();
	}
	public UserReview(Long userId, Long techId, Integer rating, String description) {
		super();
		this.userId = userId;
		this.techId = techId;
		this.rating = rating;
		this.description = description;
	}


	public UserReview(Long reviewId, Long userId, Long techId, Integer rating, String description) {
		super();
		this.reviewId = reviewId;
		this.userId = userId;
		this.techId = techId;
		this.rating = rating;
		this.description = description;
	}
	public Long getReviewId() {
		return reviewId;
	}
	public void setReviewId(Long reviewId) {
		this.reviewId = reviewId;
	}
	public Long getUserId() {
		return userId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	public Long getTechId() {
		return techId;
	}
	public void setTechId(Long techId) {
		this.techId = techId;
	}
	public Integer getRating() {
		return rating;
	}
	public void setRating(Integer rating) {
		this.rating = rating;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	
	

}
