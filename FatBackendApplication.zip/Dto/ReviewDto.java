package com.project.fatbackend.Dto;

import com.project.fatbackend.Entity.UserReview;

public class ReviewDto {
	private Long reviewer;
	private Long reciever;
	private Integer rating;
	private String description;
	public ReviewDto(Long reviewer, Long reciever, Integer rating, String description) {
		super();
		this.reviewer = reviewer;
		this.reciever = reciever;
		this.rating = rating;
		this.description = description;
	}
	
	public ReviewDto(UserReview review) {
		this.reviewer = review.getUserId();
		this.reciever = review.getTechId();
		this.rating = review.getRating();
		this.description = review.getDescription();
		
		
	}
	

	public Long getReviewer() {
		return reviewer;
	}
	public void setReviewer(Long reviewer) {
		this.reviewer = reviewer;
	}
	public Long getReciever() {
		return reciever;
	}
	public void setReciever(Long reciever) {
		this.reciever = reciever;
	}
	public Integer getRating() {
		return rating;
	}
	public void setRating(Integer rating) {
		this.rating = rating;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	
	
}
