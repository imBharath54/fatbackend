package com.project.fatbackend.Service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.fatbackend.Dto.ReviewDto;
import com.project.fatbackend.Entity.UserReview;
import com.project.fatbackend.Repository.UserReviewRepository;


@Service
public class UserReviewImpl implements ReviewService {
	
	@Autowired
	UserReviewRepository userReviewRepository;

	@Override
	public boolean addReview(ReviewDto review) {
		// TODO Auto-generated method stub
		
		UserReview r = new UserReview(review);
		UserReview savedReview = userReviewRepository.save(r);
		if(savedReview != null) {
			return true;
		}
		return false;
		

	}

	@Override
	public ReviewDto getReview(Long bookingId) {
		// TODO Auto-generated method stub
		
		Optional<UserReview> review = userReviewRepository.findById(bookingId);
		return new ReviewDto(review.get());

	}

}
