package com.project.fatbackend.Service;

import java.util.List;

import com.project.fatbackend.Entity.Service;

public interface ServicesService {
	
	public Service addService(String name,String description,String price);
	public List<Service> getServices();
	public Service getServiceById(Long id);

}
