package com.project.fatbackend.Service;

public enum Status {
	PENDING,ACCEPTED,ONGOING,COMPLETED,REJECTED


}
