package com.project.fatbackend.Service;

import java.util.List;

import com.project.fatbackend.Entity.Booking;

public interface BookingService {
	Booking createBooking(Booking booking);
	Booking getBooking(Long id);
	Booking assignTechnician(Long id);
	Booking setStatus(Status status);
	boolean save(Booking booking);
	List<Booking> getBookingsById(Long id);
	
	

}
