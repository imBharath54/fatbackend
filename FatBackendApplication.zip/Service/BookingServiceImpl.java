package com.project.fatbackend.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.fatbackend.Entity.Booking;
import com.project.fatbackend.Repository.BookingRepository;


@Service
public class BookingServiceImpl implements BookingService {
	
	@Autowired
	BookingRepository bookingRepository;

	@Override
	public Booking createBooking(Booking booking) {
		try {
			return bookingRepository.save(booking);
		}
		catch(Exception e) {
			return null;
		}
		// TODO Auto-generated method stub
	}

	@Override
	public Booking getBooking(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Booking assignTechnician(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Booking setStatus(Status status) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean save(Booking booking) {
		// TODO Auto-generated method stub
		
		try {
			
			bookingRepository.save(booking);
			return true;
		}
		catch(Exception e) {
			return false;
		}
	}

	@Override
	public List<Booking> getBookingsById(Long id) {
		// TODO Auto-generated method stub
		List<Booking> bookings = bookingRepository.findByUserId(id);
		return bookings;
	}

	

}
