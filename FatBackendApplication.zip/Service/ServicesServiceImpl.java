package com.project.fatbackend.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.project.fatbackend.Entity.Service;
import com.project.fatbackend.Repository.ServiceRepository;

@org.springframework.stereotype.Service
public class ServicesServiceImpl implements ServicesService {
	
	@Autowired
	private ServiceRepository serviceRepository;

	@Override
	public Service addService(String name,String description,String price) {
		
		Service service = new Service(name,description,null,price);
		// TODO Auto-generated method stub
		Service service1 = serviceRepository.save(service);
		return service1;
	}

	@Override
	public List<Service> getServices() {
		// TODO Auto-generated method stub
//		return null;
		return serviceRepository.findAll();
	}

	@Override
	public Service getServiceById(Long id) {
		// TODO Auto-generated method stub
//		return null;
		
		Service service = serviceRepository.getById(id);
		return service;
	}

}
