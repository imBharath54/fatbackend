package com.project.fatbackend.Service;

import com.project.fatbackend.Dto.ReviewDto;

public interface ReviewService {
	
	public boolean addReview(ReviewDto review);
	public ReviewDto getReview(Long bookingId);
	
}
