package com.project.fatbackend.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.fatbackend.Entity.Service;

public interface ServiceRepository extends JpaRepository<Service, Long> {

}
