package com.project.fatbackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.CrossOrigin;

@SpringBootApplication
//@CrossOrigin(origins = "http://localhost:3000") // Allow requests from this origin
public class FatBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(FatBackendApplication.class, args);
	}

}
